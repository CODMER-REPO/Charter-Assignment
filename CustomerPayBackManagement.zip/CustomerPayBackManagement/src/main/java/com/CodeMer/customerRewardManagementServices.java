package com.CodeMer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class customerRewardManagementServices {
	
	@Autowired
	private customerRewardManagementReository customerRepo;
	
	public void saveTransaction(Customer customer) {
		customerRepo.save(customer);
		
	}
	
	
	

}
