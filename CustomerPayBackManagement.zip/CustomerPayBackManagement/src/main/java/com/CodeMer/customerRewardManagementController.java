package com.CodeMer;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class customerRewardManagementController {
	
	private customerRewardManagementServices customerServices;
	
	@PostMapping(value="/newTransaction")
	public void saveNewTransaction(Customer customer) {
		customerServices.saveTransaction(customer);
		
	}
	// fields, getters and setters
	

}

