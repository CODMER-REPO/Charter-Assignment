package com.CodeMer;

import org.springframework.data.jpa.repository.JpaRepository;

public interface customerRewardManagementReository extends JpaRepository<Customer, Integer> {
	
	
	

}
